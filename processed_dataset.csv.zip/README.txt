Contenido de processed_dataset.csv.zip
-------------------------------------
CSV base (OHE, sin escalado ni SMOTE):
- train_ohe.csv       -> X_train (OHE) + salario_encoded + salario
- valid_ohe.csv       -> X_valid (OHE) + salario_encoded + salario
- kaggle_ohe.csv      -> X_test_kaggle (OHE) + ID

CSV con selección RFECV+LR aplicada:

- train_rfecv_lr.csv
- valid_rfecv_lr.csv
- kaggle_rfecv_lr.csv
  (Proyectado a las features seleccionadas por RFECV-LR, SIN escalar las numéricas)

Nuevos CSV proyectados a RFECV+LR (con escalado aplicado a las columnas numéricas):

- train_rfecv_std.csv   -> Estandarizado (StandardScaler) + SMOTE
- valid_rfecv_std.csv   -> Estandarizado (StandardScaler)
- kaggle_rfecv_std.csv  -> Estandarizado (StandardScaler)

- train_rfecv_minmax.csv -> Normalizado (MinMaxScaler) + SMOTE
- valid_rfecv_minmax.csv -> Normalizado (MinMaxScaler)
- kaggle_rfecv_minmax.csv -> Normalizado (MinMaxScaler)

Metadatos:
- selected_features_RFECV_LR.json
- meta.json (nombres OHE, máscara RFECV, columnas crudas, clases del LabelEncoder, modas de imputación)

Notas:
- SMOTE solo se aplicó a los datasets de TRAIN (STD y MinMax) para el balanceo.
- La máscara RFECV-LR se entrenó en TRAIN (STD) y se proyectó tal cual a VALID y KAGGLE.
- En supervised.ipynb se deben usar los conjuntos de escalado (STD o MinMax) según el modelo.
